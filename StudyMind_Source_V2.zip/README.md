# StudyMind

Nouvelle version de StudyMind, une application éducative inspirée des systèmes RPG et des manhwa.

## Contenu
- Projet Flutter dans `studymind_flutter/`
- Progression PR et rangs jusqu'à SSS
- Sauvegarde locale des préférences et de la progression
- Interface d'administration et parcours de formation proposés

## Important
L'écran d'administration présent dans cette version est une interface de présentation. Les nominations, codes à usage unique, permissions, journaux d'audit et révocations ne sont pas encore sécurisés par un serveur. Ne l'utilisez pas pour gérer de vrais comptes administrateurs avant l'ajout d'un backend sécurisé.
